# pollution-control-grievance-system
Solution for IBM- 2020 Call for Code Global Challenge Track 2 - Climate Change

Download the zip copy of this repository on your local system and open index.html 
